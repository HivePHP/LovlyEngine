<?php
/*
 * Copyright (c) 2025 hivephp OldVkDev
 *
 *  For the full copyright and license information, please view the LICENSE
 *   file that was distributed with this source code.
 *
 */
declare(strict_types=1);

namespace App\Http\Controllers;

class HomeController extends Controller
{
    public function showLogin(): void
    {
        $this->assets->addCss('css/home/login.css');
        $this->assets->addJs('js/home/login.js');

        echo $this->view->render('home/login', [
            'title' => 'Авторизация',
        ]);
    }

    public function showRegister(): void
    {
        $this->assets->addCss('css/home/register.css');
        $this->assets->addJs('js/home/register.js');

        echo $this->view->render('home/register', [
            'title' => 'Регистрация'
        ]);
    }
}