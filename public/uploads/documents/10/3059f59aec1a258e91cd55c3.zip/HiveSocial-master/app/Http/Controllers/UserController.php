<?php
/*
 * Copyright (c) 2025 hivephp OldVkDev
 *
 *  For the full copyright and license information, please view the LICENSE
 *   file that was distributed with this source code.
 *
 */

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\UserRepository;
use HivePHP\Assets\Assets;
use HivePHP\Database\Database;
use HivePHP\Http\Cookie;
use HivePHP\Http\Request;
use HivePHP\Http\Response;
use HivePHP\View\View;

class UserController extends Controller
{
    public function __construct(
        Request $request,
        Response $response,
        View $view,
        Database $db,
        Assets $assets,
        Cookie $cookies,
        private readonly UserRepository $users,
    ) {
        parent::__construct($request, $response, $view, $db, $assets, $cookies);
    }

    public function show(int $id): void
    {
//        $config = Config::get('app');

        $userInfo = $this->users->findInfoById($id);

        $this->assets->addCss('css/profile/profile.css');
//        $this->assets->addJs('js/home/login.js');

        echo $this->view->render('profile/profile', [
            'title' => trim($userInfo['name'] . ' ' . $userInfo['surname']),
            'name' => $userInfo['name'],
            'surname' => $userInfo['surname'],
        ]);
    }
}