<?php
/*
 * Copyright (c) 2025 hivephp OldVkDev
 *
 *  For the full copyright and license information, please view the LICENSE
 *   file that was distributed with this source code.
 *
 */


declare(strict_types=1);

namespace App\Http;

use App\Http\Middleware\Auth;
use App\Http\Middleware\Guest;
use App\Http\Middleware\WebAssets;

final class Kernel
{
    public static array $middlewareAliases = [
        'web'   => WebAssets::class,
        'auth'  => Auth::class,
        'guest' => Guest::class
    ];
}