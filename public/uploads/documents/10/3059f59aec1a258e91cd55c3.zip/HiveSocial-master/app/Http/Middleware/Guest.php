<?php
/*
 * Copyright (c) 2025 hivephp OldVkDev
 *
 *  For the full copyright and license information, please view the LICENSE
 *   file that was distributed with this source code.
 *
 */

declare(strict_types=1);

namespace App\Http\Middleware;

use App\Services\AuthService;
use HivePHP\Http\MiddlewareInterface;
use HivePHP\Http\Request;
use HivePHP\Http\Response;

final class Guest implements MiddlewareInterface
{
    public function __construct(
        private readonly AuthService $auth
    ) {}

    public function handle(Request $request, Response $response): bool
    {
        if ($this->auth->check()) {
            $user = $this->auth->user();
            $response->redirect('/id' . $user['id']);
            return false;
        }
        return true;
    }
}