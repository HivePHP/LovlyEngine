<?php
/*
 * Copyright (c) 2025 hivephp OldVkDev
 *
 *  For the full copyright and license information, please view the LICENSE
 *   file that was distributed with this source code.
 *
 */
declare(strict_types=1);

namespace App\Http\Middleware;

use HivePHP\Assets\Assets;
use HivePHP\Http\MiddlewareInterface;
use HivePHP\Http\Request;
use HivePHP\Http\Response;

final class WebAssets implements MiddlewareInterface
{
    public function __construct(
        private readonly Assets $assets
    ) {}

    public function handle(Request $request, Response $response): bool
    {
        $this->assets->addCss('css/main.css');
        $this->assets->addCss('css/components/button.css');
//        Assets::addJs('js/main.js');

        return true;
    }
}