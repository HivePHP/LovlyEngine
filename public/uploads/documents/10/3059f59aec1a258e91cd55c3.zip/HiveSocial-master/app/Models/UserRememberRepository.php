<?php
/*
 * Copyright (c) 2025 HivePHP OldVkDev
 *
 *  For the full copyright and license information, please view the LICENSE
 *   file that was distributed with this source code.
 *
 */
declare(strict_types=1);

namespace App\Models;

use HivePHP\Database\Database;

class UserRememberRepository
{
    public function __construct(
        private readonly Database $db
    ) {}

    public function create(int $id, string $hash, string $ua, string $ip, string $exp): void
    {
        $this->db->execute(
            "INSERT INTO user_remember_tokens (user_id, token_hash, user_agent, ip, expires_at) VALUES (:uid, :hash, :ua, :ip, :exp)",
            [
                'uid'  => $id,
                'hash' => $hash,
                'ua'   => $ua,
                'ip'   => $ip,
                'exp'  => $exp
            ]
        );
    }

    public function deleteByUserId(int $id): void
    {
        $this->db->execute(
            "DELETE FROM user_remember_tokens WHERE user_id = :uid",
            ['uid' => $id]
        );
    }

    public function deleteByTokenHash(string $hash): void
    {
        $this->db->execute(
            "DELETE FROM user_remember_tokens WHERE token_hash = :hash",
            ['hash' => $hash]
        );
    }

    public function findValid(string $hash, string $ua): ?array
    {
        return $this->db->fetch(
            "SELECT * FROM user_remember_tokens
             WHERE token_hash = :hash
               AND user_agent = :ua
               AND expires_at > NOW()
             LIMIT 1",
            [
                'hash' => $hash,
                'ua'   => $ua,
            ]
        );
    }
}