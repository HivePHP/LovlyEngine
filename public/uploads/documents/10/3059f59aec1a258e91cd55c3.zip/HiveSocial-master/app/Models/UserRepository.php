<?php
/*
 * Copyright (c) 2025 hivephp OldVkDev
 *
 *  For the full copyright and license information, please view the LICENSE
 *   file that was distributed with this source code.
 *
 */
declare(strict_types=1);

namespace App\Models;

use HivePHP\Database\Database;

final class UserRepository
{
    public function __construct(
        private readonly Database $db
    ) {}

    public function create(array $data): int
    {
        $this->db->execute(
            "INSERT INTO users
             (name, surname, sex, email, password_hash, city, country, day, month, year)
             VALUES
             (:name, :surname, :sex, :email, :password_hash, :city, :country, :day, :month, :year)",
            $data
        );

        return (int)$this->db->lastInsertId();
    }

    public function findByEmail(string $email): ?array
    {
        return $this->db->fetch(
            "SELECT * FROM users WHERE email = :email LIMIT 1",
            ['email' => $email]
        ) ?: null;
    }

    public function findById(int $id): ?array
    {
        return $this->db->fetch(
            "SELECT * FROM users WHERE id = :id LIMIT 1",
            ['id' => $id]
        ) ?: null;
    }

    public function findInfoById(int $id): ?array
    {
        return $this->db->fetch(
            "SELECT
            id,
            name,
            surname,
            sex,
            city,
            country,
            day,
            month,
            year
         FROM users
         WHERE id = :id
         LIMIT 1",
            ['id' => $id]
        ) ?: null;
    }
}