<?php
/*
 * Copyright (c) 2025 HivePHP LovlyEngine
 *
 *  For the full copyright and license information, please view the LICENSE
 *   file that was distributed with this source code.
 *
 */
declare(strict_types=1);

namespace App\Services;

use App\Models\UserRememberRepository;
use App\Models\UserRepository;
use HivePHP\Http\Cookie;
use HivePHP\Http\Request;

final class AuthService
{
    private const COOKIE_NAME = 'remember_token';
    private const TTL = 2592000; // 30 days

    private bool $resolved = false;
    private ?array $user = null;

    public function __construct(
        private readonly Cookie $cookies,
        private readonly Request $request,
        private readonly UserRepository $users,
        private readonly UserRememberRepository $tokens,
    ) {}

    public function check(): bool
    {
        return $this->user() !== null;
    }

    public function user(): ?array
    {
        if ($this->resolved) {
            return $this->user;
        }

        $this->resolved = true;

        if (!empty($_SESSION['uid'])) {
            return $this->user = $this->users->findById((int)$_SESSION['uid']);
        }

        if ($this->cookies->has(self::COOKIE_NAME)) {
            return $this->user = $this->loginByRememberToken(
                $this->cookies->get(self::COOKIE_NAME)
            );
        }

        return null;
    }

    public function login(int $userId, bool $remember): void
    {
        session_regenerate_id(true);
        $_SESSION['uid'] = $userId;

        if ($remember) {
            $this->rotateRememberToken($userId);
        }
    }

    public function logout(): void
    {
        if ($this->cookies->has(self::COOKIE_NAME)) {
            $this->deleteRememberToken(
                $this->cookies->get(self::COOKIE_NAME)
            );
            $this->cookies->delete(self::COOKIE_NAME);
        }

        unset($_SESSION['uid']);
        session_regenerate_id(true);
    }

    private function rotateRememberToken(int $userId): void
    {
        /* Генерируем токин */
        $token = bin2hex(random_bytes(32));
        $hash  = hash('sha256', $token);

        /* Удоляем старый */
        $this->tokens->deleteByUserId($userId);

        /* создаем новый */
        $this->tokens->create($userId, $hash, $this->request->userAgent(), $this->request->ip(), date('Y-m-d H:i:s', time() + self::TTL));

        /* Записываем в куку */
        $this->cookies->set(self::COOKIE_NAME, $token, self::TTL);
    }

    private function loginByRememberToken(string $token): ?array
    {

        $hash = hash('sha256', $token);

        $row = $this->tokens->findValid($hash, $this->request->userAgent());

        if (!$row) {
            return null;
        }

        $user = $this->users->findById((int)$row['user_id']);
        if (!$user) {
            return null;
        }

        $this->login($user['id'], true);
        return $user;
    }

    private function deleteRememberToken(string $token): void
    {
        $this->tokens->deleteByTokenHash(hash('sha256', $token));
    }
}