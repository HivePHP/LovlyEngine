<?php
/*
 * Copyright (c) 2025 hivephp OldVkDev
 *
 *  For the full copyright and license information, please view the LICENSE
 *   file that was distributed with this source code.
 *
 */
declare(strict_types=1);

return [
    'path'     => '/',
    'domain'   => null,     // null = текущий домен
    'secure'   => true,     // HTTPS only
    'httponly' => true,
    'samesite' => 'Lax',    // Lax | Strict | None
];