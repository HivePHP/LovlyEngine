<?php
/*
 * Copyright (c) 2025 hivephp OldVkDev
 *
 *  For the full copyright and license information, please view the LICENSE
 *   file that was distributed with this source code.
 *
 */
declare(strict_types=1);

return [
    'cache' => BASE_PATH . '/storage/cache/view',
    'auto_reload' => true,   // true только в dev
    'debug' => true,         // true только в dev
    'strict_variables' => true,
];