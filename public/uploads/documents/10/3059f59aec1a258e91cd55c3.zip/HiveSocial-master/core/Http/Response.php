<?php
/*
 * Copyright (c) 2025 HivePHP OldVkDev
 *
 *  For the full copyright and license information, please view the LICENSE
 *   file that was distributed with this source code.
 *
 */

declare(strict_types=1);

namespace HivePHP\Http;

use JetBrains\PhpStorm\NoReturn;

final class Response
{
    public function json(mixed $data, int $status = 200): void
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');

        echo json_encode(
            $data,
            JSON_UNESCAPED_UNICODE
        );
    }

    public function redirect(string $url, int $status = 302): void
    {
        if (headers_sent()) {
            return;
        }

        http_response_code($status);
        header('Location: ' . $url);
        exit;
    }
}
