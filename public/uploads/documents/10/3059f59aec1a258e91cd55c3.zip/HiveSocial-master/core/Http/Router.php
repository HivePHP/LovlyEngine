<?php
declare(strict_types=1);

namespace HivePHP\Http;

use App\Http\Kernel;
use HivePHP\Support\Container;
use RuntimeException;
use JetBrains\PhpStorm\NoReturn;

final class Router
{
    private array $routes = [];
    private array $pendingMiddleware = [];

    public function __construct(
        private Container $container
    ) {}

    /* ===================== */
    /* Fluent middleware     */
    /* ===================== */

    public function middleware(string ...$middleware): self
    {
        foreach ($middleware as $alias) {
            $this->pendingMiddleware[] = $alias;
        }

        return $this;
    }

    /* ===================== */
    /* Routes                */
    /* ===================== */

    public function get(string $pattern, callable|array $handler): Route
    {
        return $this->add('GET', $pattern, $handler);
    }

    public function post(string $pattern, callable|array $handler): Route
    {
        return $this->add('POST', $pattern, $handler);
    }

    private function add(string $method, string $pattern, callable|array $handler): Route
    {
        $pattern = rtrim($pattern, '/') ?: '/';

        $regex = preg_replace_callback(
            '#\{(\w+)\}#',
            static fn($m) => '(?P<' . $m[1] . '>\d+)',
            $pattern
        );

        $route = new Route(
            $method,
            '#^' . $regex . '$#',
            $handler,
            $this->pendingMiddleware
        );

        $this->pendingMiddleware = [];
        $this->routes[] = $route;

        return $route;
    }

    /* ===================== */
    /* Dispatch              */
    /* ===================== */

    public function dispatch(Request $request, Response $response): void
    {
        $uri    = rtrim($request->getPath(), '/') ?: '/';
        $method = $request->getMethod();

        foreach ($this->routes as $route) {
            if ($route->method !== $method) {
                continue;
            }

            if (!preg_match($route->pattern, $uri, $matches)) {
                continue;
            }

            $params = array_filter(
                $matches,
                static fn($k) => is_string($k),
                ARRAY_FILTER_USE_KEY
            );

            // ---------- Middleware ----------
            foreach ($this->resolveMiddleware($route->middleware) as $middlewareClass) {
                $middleware = $this->container->get($middlewareClass);

                if (!$middleware instanceof MiddlewareInterface) {
                    throw new RuntimeException(
                        "$middlewareClass must implement MiddlewareInterface"
                    );
                }

                if ($middleware->handle($request, $response) === false) {
                    return;
                }
            }

            // ---------- Controller ----------
            $this->callHandler($route->handler, $params);
            return;
        }

        $this->abort404();
    }

    /* ===================== */
    /* Helpers               */
    /* ===================== */

    private function resolveMiddleware(array $middleware): array
    {
        $resolved = [];

        foreach ($middleware as $alias) {
            if (!isset(Kernel::$middlewareAliases[$alias])) {
                throw new RuntimeException("Middleware [$alias] not registered");
            }

            $resolved[] = Kernel::$middlewareAliases[$alias];
        }

        return $resolved;

    }

    private function callHandler(callable|array $handler, array $params): void
    {
        if (is_callable($handler)) {
            call_user_func_array($handler, $params);
            return;
        }

        [$class, $method] = $handler;

        $controller = $this->container->get($class);
        call_user_func_array([$controller, $method], $params);
    }

    #[NoReturn]
    private function abort404(): void
    {
        http_response_code(404);
        echo '404 Not Found';
        exit;
    }
}
