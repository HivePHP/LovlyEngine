<?php
/*
 * Copyright (c) 2025 HivePHP OldVkDev
 *
 *  For the full copyright and license information, please view the LICENSE
 *   file that was distributed with this source code.
 *
 */


namespace HivePHP\Providers;

use HivePHP\Http\Request;
use HivePHP\Http\Response;
use HivePHP\Http\Router;
use HivePHP\Support\Container;

class RouterServiceProvider implements ServiceProviderInterface
{
    public function register(Container $container): void
    {
        $router  = new Router($container);

        require BASE_PATH . '/routes/web.php';
        $router->dispatch(
            $container->get(Request::class),
            $container->get(Response::class)
        );
    }

    public function boot(Container $container): void{}
}