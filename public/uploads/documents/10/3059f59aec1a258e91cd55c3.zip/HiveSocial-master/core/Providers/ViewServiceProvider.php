<?php
/*
 * Copyright (c) 2025 HivePHP OldVkDev
 *
 *  For the full copyright and license information, please view the LICENSE
 *   file that was distributed with this source code.
 *
 */


namespace HivePHP\Providers;

use HivePHP\Assets\Assets;
use HivePHP\Support\Config;
use HivePHP\Support\Container;
use HivePHP\View\TwigFactory;
use HivePHP\View\View;
use Twig\Environment;

class ViewServiceProvider implements ServiceProviderInterface
{
    public function register(Container $container): void
    {
        /* Register View */
        $container->set(Environment::class, function (Container $c) {
            $factory = new TwigFactory();

            return $factory->create(
                Config::get('view'),
                $c->get(Assets::class)
            );
        });

        // View
        $container->set(View::class, function (Container $c) {
            return new View(
                $c->get(Environment::class)
            );
        });
    }

    public function boot(Container $container): void{}
}