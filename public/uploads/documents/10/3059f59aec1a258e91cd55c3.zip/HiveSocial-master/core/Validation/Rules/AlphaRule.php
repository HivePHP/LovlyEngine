<?php
/*
 * Copyright (c) 2025 HivePHP OldVkDev
 *
 *  For the full copyright and license information, please view the LICENSE
 *   file that was distributed with this source code.
 *
 */
declare(strict_types=1);

namespace HivePHP\Validation\Rules;

use HivePHP\Validation\RuleInterface;

final class AlphaRule implements RuleInterface {
    public function check(mixed $value, array $data): bool
    {
        return is_string($value)
            && preg_match('/^[a-zA-Zа-яА-ЯёЁ\-]+$/u', $value);
    }
    public function message(string $field): string
    {
        return "{$field} только буквы";
    }
}
