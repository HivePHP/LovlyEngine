<?php
/*
 * Copyright (c) 2025 hivephp OldVkDev
 *
 *  For the full copyright and license information, please view the LICENSE
 *   file that was distributed with this source code.
 *
 */
declare(strict_types=1);

use App\Http\Controllers\AuthController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\UserController;
use HivePHP\Http\Router;

/** @var Router $router */

$router->middleware('guest', 'web')->       get('/', [HomeController::class, 'showLogin']);
$router->middleware('guest', 'web')->       get('/reg', [HomeController::class, 'showRegister']);
$router->middleware('guest')->              post('/login', [AuthController::class, 'login']);
$router->middleware('guest')->              post('/register', [AuthController::class, 'register']);
$router->middleware('auth')->               get('/logout', [AuthController::class, 'logout']);

$router->middleware('web')->get('/id{id}', [UserController::class, 'show']);