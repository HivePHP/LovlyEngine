<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* layouts/main.twig */
class __TwigTemplate_0afeecb09e8937fc5508517e9e3659dd extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "<!doctype html>
<html lang=\"ru\">
<head>
    <meta charset=\"UTF-8\">
    <meta name=\"viewport\"
          content=\"width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"ie=edge\">
    ";
        // line 8
        yield $this->env->getFunction('assets_css')->getCallable()();
        yield "
    <title>";
        // line 9
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["title"]) || array_key_exists("title", $context) ? $context["title"] : (function () { throw new RuntimeError('Variable "title" does not exist.', 9, $this->source); })()), "html", null, true);
        yield "</title>
</head>
<body>
    <header class=\"header\">
        <div class=\"container\">
            <div class=\"left-group\">
                <div class=\"logo\">
                    <a href=\"/\">";
        // line 16
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 16, $this->source); })()), "name", [], "any", false, false, false, 16), "html", null, true);
        yield "</a>
                </div>
                <div class=\"search\">

                </div>
            </div>
            <div class=\"menu-head\">
                <a href=\"/logout\">Выйти</a>
            </div>
        </div>
    </header>


    <div class=\"container\">
        ";
        // line 30
        yield from $this->unwrap()->yieldBlock('content', $context, $blocks);
        // line 31
        yield "    </div>

    ";
        // line 33
        yield $this->env->getFunction('assets_js')->getCallable()();
        yield "
</body>
</html>";
        yield from [];
    }

    // line 30
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "layouts/main.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  97 => 30,  89 => 33,  85 => 31,  83 => 30,  66 => 16,  56 => 9,  52 => 8,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("<!doctype html>
<html lang=\"ru\">
<head>
    <meta charset=\"UTF-8\">
    <meta name=\"viewport\"
          content=\"width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0\">
    <meta http-equiv=\"X-UA-Compatible\" content=\"ie=edge\">
    {{ assets_css() }}
    <title>{{ title }}</title>
</head>
<body>
    <header class=\"header\">
        <div class=\"container\">
            <div class=\"left-group\">
                <div class=\"logo\">
                    <a href=\"/\">{{ app.name }}</a>
                </div>
                <div class=\"search\">

                </div>
            </div>
            <div class=\"menu-head\">
                <a href=\"/logout\">Выйти</a>
            </div>
        </div>
    </header>


    <div class=\"container\">
        {% block content %}{% endblock %}
    </div>

    {{ assets_js() }}
</body>
</html>", "layouts/main.twig", "C:\\OSPanel\\domains\\localhost\\views\\layouts\\main.twig");
    }
}
